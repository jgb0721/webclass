// 시드값 생성 함수 (성별 포함)
function generateSeed(initials, birthdate, gender) {
    const today = new Date();
    const year = today.getFullYear();
    const month = (today.getMonth() + 1).toString().padStart(2, '0');
    const day = today.getDate().toString().padStart(2, '0');
    
    // 초성, 생년월일, 성별, 오늘 날짜를 결합하여 고유한 시드를 만듦
    const fullSeed = initials + birthdate + gender + year + month + day;
    return fullSeed;
}

// 문자열을 숫자화하는 해시 함수 (시드로 사용할 숫자 생성)
function stringToSeed(str) {
    let seed = 0;
    for (let i = 0; i < str.length; i++) {
        seed = (seed << 5) - seed + str.charCodeAt(i);
        seed &= seed; // 32비트 정수로 변환
    }
    return seed;
}

// 명언을 선택하는 함수 (시드 기반)
function getQuoteBasedOnSeed(seed, quotes) {
    const index = Math.abs(seed) % quotes.length; // 시드를 사용해 인덱스 생성
    return quotes[index]; // 해당 인덱스의 명언을 반환
}

// 명언을 JSON 파일에서 불러오는 함수
async function loadQuotes() {
    try {
        const response = await fetch('quotes.json');
        if (!response.ok) {
            throw new Error("명언 파일을 불러오는 데 실패했습니다.");
        }
        const quotes = await response.json();
        return quotes; // 명언 리스트 반환
    } catch (error) {
        console.error("명언을 불러오는 데 오류가 발생했습니다:", error);
        return []; // 오류 발생 시 빈 배열 반환
    }
}

// 명언을 화면에 표시하는 함수
function displayQuote(quote) {
    const quoteContainer = document.getElementById('quote-container');
    quoteContainer.innerHTML = `<p>${quote}</p>`; // 명언을 HTML로 추가
}

// 명언 보기 버튼 클릭 시 처리
document.getElementById('show-quote').addEventListener('click', async (event) => {
    event.preventDefault(); // 폼 제출 방지

    // 정보 입력 폼 숨기기
    document.getElementById('quote-form').style.display = 'none';

    // 뒤로가기 버튼 보이기
    document.getElementById('back-button').style.display = 'block';

    // 사용자 입력 값 받기
    const initials = document.getElementById('initials').value;
    const birthdate = document.getElementById('birthdate').value;
    const gender = document.querySelector('input[name="gender"]:checked').value; // 성별 값

    // 시드값 생성
    const seedString = generateSeed(initials, birthdate, gender);
    const seed = stringToSeed(seedString);

    // 명언 불러오기
    const quotes = await loadQuotes();

    // 시드 기반으로 명언 선택
    const quote = getQuoteBasedOnSeed(seed, quotes);
    
    // 명언을 화면에 표시
    displayQuote(quote);
});

// 뒤로가기 버튼 클릭 시 처리
document.getElementById('back-button').addEventListener('click', () => {
    // 정보 입력 폼 보이기
    document.getElementById('quote-form').style.display = 'block';

    // 명언 영역 숨기기
    document.getElementById('quote-container').innerHTML = '';

    // 뒤로가기 버튼 숨기기
    document.getElementById('back-button').style.display = 'none';
});

// 입력이 완료되었는지 확인하여 '명언 보기' 버튼 활성화
document.getElementById('quote-form').addEventListener('input', function() {
    const initials = document.getElementById('initials').value;
    const birthdate = document.getElementById('birthdate').value;
    const gender = document.querySelector('input[name="gender"]:checked');

    // 모든 입력이 완료되면 버튼을 활성화
    const submitButton = document.getElementById('show-quote');
    if (initials && birthdate && gender) {
        submitButton.disabled = false;
    } else {
        submitButton.disabled = true;
    }
});

function displayTodayDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1;  // 월은 0부터 시작하므로 1을 더함
    const day = today.getDate();

    // "YYYY-MM-DD" 형식으로 날짜 포맷
    const formattedDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;

    // 오늘 날짜를 HTML 요소에 표시
    document.getElementById('today-date').innerText = `오늘 날짜: ${formattedDate}`;
}

// 페이지 로드 시 오늘 날짜 표시
window.onload = function() {
    displayTodayDate(); // 페이지 로드 시 날짜 표시
};